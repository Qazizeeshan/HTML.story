const video = document.getElementById('video');
const playPauseBtn = document.getElementById('playPause');
const stopBtn = document.getElementById('stop');
const seekBar = document.getElementById('seekBar');
const timeDisplay = document.getElementById('timeDisplay');

// Play or Pause Video
playPauseBtn.addEventListener('click', () => {
  if (video.paused) {
    video.play();
    playPauseBtn.textContent = 'Pause';
  } else {
    video.pause();
    playPauseBtn.textContent = 'Play';
  }
});

// Stop Video
stopBtn.addEventListener('click', () => {
  video.pause();
  video.currentTime = 0;
  playPauseBtn.textContent = 'Play';
});

// Update Seek Bar and Time
video.addEventListener('timeupdate', () => {
  seekBar.value = (video.currentTime / video.duration) * 100 || 0;

  const currentMinutes = Math.floor(video.currentTime / 60);
  const currentSeconds = Math.floor(video.currentTime % 60);
  const totalMinutes = Math.floor(video.duration / 60);
  const totalSeconds = Math.floor(video.duration % 60);

  timeDisplay.textContent = `${currentMinutes.toString().padStart(2, '0')}:${currentSeconds.toString().padStart(2, '0')} / ${totalMinutes.toString().padStart(2, '0')}:${totalSeconds.toString().padStart(2, '0')}`;
});

// Seek Video
seekBar.addEventListener('input', () => {
  video.currentTime = (seekBar.value / 100) * video.duration;
});
